# frozen_string_literal: false
create_makefile("-test-/fatal/rb_fatal")
